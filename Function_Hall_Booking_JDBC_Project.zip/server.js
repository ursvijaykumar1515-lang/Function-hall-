const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "frontend")));

app.get("/api/status", (req, res) => {
  res.json({ ok: true, message: "Node frontend server is running" });
});

app.listen(PORT, () => {
  console.log(`Frontend running at http://localhost:${PORT}`);
});