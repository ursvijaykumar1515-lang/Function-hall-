CREATE DATABASE IF NOT EXISTS function_hall;
USE function_hall;

CREATE TABLE IF NOT EXISTS halls(
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 category ENUM('PLAIN','CHAIRS','DECORATION') NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 capacity INT DEFAULT 100,
 available BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS food_items(
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 category ENUM('VEG','NON_VEG') NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 available BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS bookings(
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(120) NOT NULL,
 phone VARCHAR(20) NOT NULL,
 event_date DATE,
 event_type VARCHAR(60),
 total_amount DECIMAL(10,2) NOT NULL,
 payment_status VARCHAR(30) DEFAULT 'PENDING',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO halls(name,category,price,capacity) VALUES
('Royal Garden Hall','PLAIN',35000,300),('Grand Palace Hall','PLAIN',45000,500),
('Pearl Banquet Hall','PLAIN',30000,250),('Crystal Convention Hall','PLAIN',55000,800),
('Royal Hall + Chairs','CHAIRS',50000,300),('Classic Hall + Chairs','CHAIRS',42000,350),
('Lake View + Chairs','CHAIRS',60000,500),('Mini Hall + Chairs','CHAIRS',28000,150),
('Royal Complete Package','DECORATION',90000,300),('Wedding Decor Package','DECORATION',125000,500),
('Birthday Decor Package','DECORATION',70000,250),('Luxury Decor Package','DECORATION',150000,800);

INSERT INTO food_items(name,category,price) VALUES
('Paneer Tikka','VEG',300),('Veg Biryani','VEG',335),('Gobi Manchurian','VEG',370),
('Paneer Butter Masala','VEG',405),('Dal Tadka','VEG',440),('Veg Fried Rice','VEG',475),
('Mushroom Curry','VEG',510),('Kaju Curry','VEG',545),('Baby Corn Fry','VEG',580),
('Aloo Gobi','VEG',615),('Chilli Paneer','VEG',650),('Veg Noodles','VEG',685),
('Palak Paneer','VEG',720),('Malai Kofta','VEG',755),('Mix Veg Curry','VEG',790),
('Sambar','VEG',825),('Rasam','VEG',860),('Curd Rice','VEG',895),
('Gulab Jamun','VEG',930),('Fruit Salad','VEG',965),('Ice Cream','VEG',1000),('Masala Dosa','VEG',1035),
('Chicken Biryani','NON_VEG',450),('Mutton Biryani','NON_VEG',495),('Chicken 65','NON_VEG',540),
('Chicken Tikka','NON_VEG',585),('Butter Chicken','NON_VEG',630),('Mutton Curry','NON_VEG',675),
('Chicken Curry','NON_VEG',720),('Fish Fry','NON_VEG',765),('Prawn Fry','NON_VEG',810),
('Chilli Chicken','NON_VEG',855),('Chicken Manchurian','NON_VEG',900),('Mutton Fry','NON_VEG',945),
('Chicken Lollipop','NON_VEG',990),('Tandoori Chicken','NON_VEG',1035),('Pepper Chicken','NON_VEG',1080),
('Fish Curry','NON_VEG',1125),('Prawn Curry','NON_VEG',1170),('Egg Curry','NON_VEG',1215),
('Egg Fried Rice','NON_VEG',1260),('Chicken Fried Rice','NON_VEG',1305),('Mutton Keema','NON_VEG',1350),
('Chicken Kebab','NON_VEG',1395);