const API="http://localhost:8080/api";
let cart=[];
let currentFood="veg";

const halls=[
 {id:"h1",name:"Royal Garden Hall",type:"hall",price:35000,img:"https://images.unsplash.com/photo-1507504031003-b417219a0fde?auto=format&fit=crop&w=900&q=80"},
 {id:"h2",name:"Grand Palace Hall",type:"hall",price:45000,img:"https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=900&q=80"},
 {id:"h3",name:"Pearl Banquet Hall",type:"hall",price:30000,img:"https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=900&q=80"},
 {id:"h4",name:"Crystal Convention Hall",type:"hall",price:55000,img:"https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=900&q=80"},
 {id:"c1",name:"Royal Hall + Chairs",type:"chairs",price:50000,img:"https://images.unsplash.com/photo-1507504031003-b417219a0fde?auto=format&fit=crop&w=900&q=80"},
 {id:"c2",name:"Classic Hall + Chairs",type:"chairs",price:42000,img:"https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=900&q=80"},
 {id:"c3",name:"Lake View + Chairs",type:"chairs",price:60000,img:"https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=900&q=80"},
 {id:"c4",name:"Mini Hall + Chairs",type:"chairs",price:28000,img:"https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=900&q=80"},
 {id:"d1",name:"Royal Complete Package",type:"decor",price:90000,img:"https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=900&q=80"},
 {id:"d2",name:"Wedding Decor Package",type:"decor",price:125000,img:"https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=900&q=80"},
 {id:"d3",name:"Birthday Decor Package",type:"decor",price:70000,img:"https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=900&q=80"},
 {id:"d4",name:"Luxury Decor Package",type:"decor",price:150000,img:"https://images.unsplash.com/photo-1478146896981-b80fe463b330?auto=format&fit=crop&w=900&q=80"}
];

const vegNames=["Paneer Tikka","Veg Biryani","Gobi Manchurian","Paneer Butter Masala","Dal Tadka","Veg Fried Rice","Mushroom Curry","Kaju Curry","Baby Corn Fry","Aloo Gobi","Chilli Paneer","Veg Noodles","Palak Paneer","Malai Kofta","Mix Veg Curry","Sambar","Rasam","Curd Rice","Gulab Jamun","Fruit Salad","Ice Cream","Masala Dosa"];
const nonvegNames=["Chicken Biryani","Mutton Biryani","Chicken 65","Chicken Tikka","Butter Chicken","Mutton Curry","Chicken Curry","Fish Fry","Prawn Fry","Chilli Chicken","Chicken Manchurian","Mutton Fry","Chicken Lollipop","Tandoori Chicken","Pepper Chicken","Fish Curry","Prawn Curry","Egg Curry","Egg Fried Rice","Chicken Fried Rice","Mutton Keema","Chicken Kebab"];

const foodImages=[
"https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=700&q=80",
"https://images.unsplash.com/photo-1563379091339-03246963d29a?auto=format&fit=crop&w=700&q=80",
"https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=700&q=80",
"https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=80"
];

function money(n){return Number(n).toLocaleString("en-IN")}
function showCategory(type){
  const data=halls.filter(x=>x.type===type);
  renderProducts(data);
  document.getElementById("hallProducts").scrollIntoView({behavior:"smooth",block:"start"});
}
function renderProducts(data){
  document.getElementById("hallProducts").innerHTML=data.map(x=>card(x)).join("");
}
function card(x){
 return `<article class="product">
 <img src="${x.img}">
 <div class="info"><h3>${x.name}</h3><span class="price">₹${money(x.price)}</span>
 <button class="add" onclick='addToCart(${JSON.stringify(x)})'>Add +</button></div></article>`;
}
function showFood(kind,btn){
 currentFood=kind;
 document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
 btn.classList.add("active");
 const names=kind==="veg"?vegNames:nonvegNames;
 const data=names.map((name,i)=>({id:kind+i,name,type:"food",price:kind==="veg"?300+i*35:450+i*45,img:foodImages[i%foodImages.length]}));
 document.getElementById("foodProducts").innerHTML=data.map(x=>cardFood(x)).join("");
}
function cardFood(x){
 return `<article class="product"><img src="${x.img}"><div class="info"><h3>${x.name}</h3><span class="price">₹${money(x.price)} / plate</span><button class="add" onclick='addToCart(${JSON.stringify(x)})'>Add +</button></div></article>`;
}
function addToCart(item){
 cart.push({...item,qty:1});
 updateCart();
 toast(item.name+" added to cart");
}
function removeFromCart(i){
 const el=document.querySelectorAll(".cart-row")[i];
 if(el) el.classList.add("fly");
 setTimeout(()=>{cart.splice(i,1);updateCart();},400);
}
function updateCart(){
 document.getElementById("cartCount").textContent=cart.length;
 document.getElementById("cartItems").innerHTML=cart.length?cart.map((x,i)=>`
 <div class="cart-row"><img src="${x.img}"><div class="grow"><b>${x.name}</b><br><span class="price">₹${money(x.price)}</span></div>
 <button class="remove" onclick="removeFromCart(${i})">Remove</button></div>`).join(""):"<p>Your cart is empty.</p>";
 document.getElementById("cartTotal").textContent=money(cart.reduce((s,x)=>s+x.price,0));
}
function openCart(){updateCart();document.getElementById("cartModal").classList.remove("hidden")}
function closeCart(){document.getElementById("cartModal").classList.add("hidden")}
function startPayment(){
 if(!cart.length)return toast("Add at least one item first");
 document.getElementById("payAmount").textContent=money(cart.reduce((s,x)=>s+x.price,0));
 closeCart();document.getElementById("paymentModal").classList.remove("hidden");
}
function closePayment(){document.getElementById("paymentModal").classList.add("hidden")}
async function payNow(){
 const name=document.getElementById("cardName").value.trim();
 const card=document.getElementById("cardNumber").value.trim();
 if(!name||card.length!==16)return toast("Enter demo card details correctly");
 const total=cart.reduce((s,x)=>s+x.price,0);
 const booking={customerName:document.getElementById("customerName").value||"Walk-in Customer",phone:document.getElementById("phone").value||"0000000000",eventDate:document.getElementById("eventDate").value||null,eventType:document.getElementById("eventType").value||"Other",totalAmount:total,items:cart};
 try{
   const r=await fetch(API+"/bookings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(booking)});
   if(!r.ok) throw new Error();
   const out=await r.json();
   toast("Booking confirmed! ID: "+out.bookingId);
 }catch(e){toast("Demo payment successful. Start Java backend to save booking.");}
 closePayment();cart=[];updateCart();
}
document.getElementById("bookingForm").addEventListener("submit",e=>{e.preventDefault();startPayment();});
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2500)}
showCategory("hall"); showFood("veg",document.querySelector(".tab"));
